package com.myapp.orderservice.order.event;

public record OrderAcceptedMessage (
		Long orderId
){}
