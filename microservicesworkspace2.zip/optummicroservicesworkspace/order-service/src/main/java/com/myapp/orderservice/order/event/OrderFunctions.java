package com.myapp.orderservice.order.event;

import java.util.function.Consumer;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import com.myapp.orderservice.order.domain.OrderService;
import com.myapp.orderservice.order.domain.OrderStatus;

@Configuration
public class OrderFunctions {

	private static final Logger log = LoggerFactory.getLogger(OrderFunctions.class);

	@Bean
	public Consumer<OrderDispatchedMessage> dispatchOrder(OrderService orderService) {
		return orderDispatchedMessage -> {
			log.info("The order with id {} has been dispatched", orderDispatchedMessage.orderId());
			orderService.updateOrderStatus(orderDispatchedMessage.orderId(), OrderStatus.DISPATCHED);
		};
	}

}

