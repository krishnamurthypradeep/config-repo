package com.myapp.orderservice.order.domain;

public enum OrderStatus {
	ACCEPTED,
	REJECTED,
	DISPATCHED
}
