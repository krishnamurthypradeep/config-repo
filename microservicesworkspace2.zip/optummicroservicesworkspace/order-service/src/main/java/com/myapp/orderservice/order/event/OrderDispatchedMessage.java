package com.myapp.orderservice.order.event;

public record OrderDispatchedMessage (
		Long orderId
){}
