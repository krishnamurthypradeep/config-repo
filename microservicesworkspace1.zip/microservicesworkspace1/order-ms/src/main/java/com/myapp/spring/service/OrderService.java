package com.myapp.spring.service;

import org.springframework.stereotype.Service;

import com.myapp.spring.model.Order;
import com.myapp.spring.model.OrderStatus;
import com.myapp.spring.product.Product;
import com.myapp.spring.product.ProductClient;
import com.myapp.spring.repo.OrderRepository;

import reactor.core.publisher.Flux;
import reactor.core.publisher.Mono;

@Service
public class OrderService {

	
	private final OrderRepository orderRepository;
	
	private final ProductClient productClient;

	public OrderService(ProductClient productClient, OrderRepository orderRepository) {
		
		this.productClient = productClient;
		this.orderRepository = orderRepository;
	}

	public Flux<Order> getAllOrders() {
		return orderRepository.findAll();
	}
	
	
	public Mono<Order> submitOrder(String productName,int quantity){
		
		return productClient.getProductByName(productName).log()
				.map(product -> buildAcceptedOrder(product, quantity))
				.defaultIfEmpty(buildRejectedOrder(productName, quantity))
				.flatMap(orderRepository::save);
				
	}
	
	public static Order buildAcceptedOrder(Product product,int qty) {
		return new Order(product.getName(),qty,OrderStatus.ACCEPTED);
	}

	public static Order buildRejectedOrder(String productName,int qty) {
		return new Order(productName,qty,OrderStatus.REJECTED);
	}
	
//	
	

}


// Reactive Streams

// Asynchronous

//  Non - Blocking

// BackPressure

// Publisher

// Subscriber

// Subscription

// Processor


// Publisher


// subscribe(Subscriber<? super T> s)


// Subscriber

// void onSubscribe(Subscription s)
// void onNext(T e)
// void onError(Throwable t)
// void onComplete()















