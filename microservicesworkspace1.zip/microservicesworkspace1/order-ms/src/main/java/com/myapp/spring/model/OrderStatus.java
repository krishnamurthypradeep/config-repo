package com.myapp.spring.model;

public enum OrderStatus {
	ACCEPTED,REJECTED,DISPATCHED

}
