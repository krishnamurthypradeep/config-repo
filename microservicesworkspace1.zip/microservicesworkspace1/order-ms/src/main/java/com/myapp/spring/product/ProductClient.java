package com.myapp.spring.product;

import java.time.Duration;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.web.reactive.function.client.WebClient;
import org.springframework.web.reactive.function.client.WebClientResponseException;

import reactor.core.publisher.Mono;
import reactor.util.retry.Retry;

@Component
public class ProductClient {
	
	
	private final String baseUrl = "http://CATALOG-SERVICE";
	
	@Autowired
    private WebClient.Builder webClient;
	


	

	public Mono<Product> getProductByName(String name){
		return webClient.baseUrl(baseUrl)
                .build().get().uri("/products/"+name)
				.retrieve().bodyToMono(Product.class)
				.timeout(Duration.ofSeconds(3),Mono.empty())
				.onErrorResume(WebClientResponseException.NotFound.class,
						exception -> Mono.empty())
				.retryWhen(Retry.backoff(3, Duration.ofMillis(100)));
	}

}
