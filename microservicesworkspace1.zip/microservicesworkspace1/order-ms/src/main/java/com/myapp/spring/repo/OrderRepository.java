package com.myapp.spring.repo;

import org.springframework.data.repository.reactive.ReactiveCrudRepository;

import com.myapp.spring.model.Order;

public interface OrderRepository extends ReactiveCrudRepository<Order,Long> {

}
