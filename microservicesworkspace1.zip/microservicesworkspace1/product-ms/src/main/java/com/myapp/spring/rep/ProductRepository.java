package com.myapp.spring.rep;

import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import com.myapp.spring.domain.Product;

public interface ProductRepository extends JpaRepository<Product, Long> {

	
	Optional<Product> findByName(String name);
	
	@Query("delete from Product where name= :name")
	void deleteByName(String name);
	
	
	boolean existsByName(String name);
}
