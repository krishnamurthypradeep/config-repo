package com.myapp.spring.service;

public class ProductAlreadyExistsException extends Exception {

	public ProductAlreadyExistsException() {
		// TODO Auto-generated constructor stub
	}

	public ProductAlreadyExistsException(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}

	public ProductAlreadyExistsException(Throwable cause) {
		super(cause);
		// TODO Auto-generated constructor stub
	}

	public ProductAlreadyExistsException(String message, Throwable cause) {
		super(message, cause);
		// TODO Auto-generated constructor stub
	}

	public ProductAlreadyExistsException(String message, Throwable cause, boolean enableSuppression,
			boolean writableStackTrace) {
		super(message, cause, enableSuppression, writableStackTrace);
		// TODO Auto-generated constructor stub
	}

}
