package com.myapp.spring.service;

import org.springframework.stereotype.Service;

import com.myapp.spring.domain.Product;
import com.myapp.spring.rep.ProductRepository;

@Service
public class ProductService {
	
	private final ProductRepository productRepository;

	public ProductService(ProductRepository productRepository) {
		this.productRepository = productRepository;
	}
	
	
	public Iterable<Product> viewProductList(){
		return productRepository.findAll();
	}
	
	public Product viewProductDetails(String name) throws ProductNotFundException {
		return productRepository.findByName(name)
				.orElseThrow(() -> new ProductNotFundException(name));
	}
	
	public Product addProductToCatalog(Product product) throws ProductAlreadyExistsException {
		if(productRepository.existsByName(product.getName())) {
			throw new ProductAlreadyExistsException(product.getName());
		}
			return productRepository.save(product);
		}
	

}
